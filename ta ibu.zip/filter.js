let filterbox = document.querySelector('.filter-box');
filterbox.onclick = function(){
  filterbox.classList.toggle('active');
}